
"""
Smart Waste Classification - Flask Backend
Author: The Fab Five
Description: RESTful API using Flask to serve a pre-trained CNN model for real-time image classification.
"""

from flask import Flask, request, jsonify
import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import io
from PIL import Image
import logging

# Initialize the Flask application
app = Flask(__name__)

# Load the trained model
MODEL_PATH = "resnet50_model.h5"  # Ensure this model file is in the correct directory
model = load_model(MODEL_PATH)

# Define class labels (modify as per your dataset)
class_labels = ['Organic', 'Recyclable', 'Hazardous', 'Electronic', 'General']

# Configure logging
logging.basicConfig(level=logging.INFO)

def preprocess_image(img_bytes):
    """Preprocesses image for model prediction."""
    img = Image.open(io.BytesIO(img_bytes)).convert('RGB')
    img = img.resize((224, 224))
    img_array = np.array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)
    return img_array

@app.route('/predict', methods=['POST'])
def predict():
    """API endpoint to predict waste classification from image."""
    if 'file' not in request.files:
        logging.warning("No file part in the request.")
        return jsonify({'error': 'No file part'}), 400

    file = request.files['file']
    if file.filename == '':
        logging.warning("No selected file.")
        return jsonify({'error': 'No selected file'}), 400

    try:
        img_bytes = file.read()
        processed_img = preprocess_image(img_bytes)
        prediction = model.predict(processed_img)
        class_idx = np.argmax(prediction)
        confidence = float(np.max(prediction))
        label = class_labels[class_idx]

        logging.info(f"Prediction: {label} ({confidence:.3f})")

        return jsonify({
            'label': label,
            'confidence': round(confidence, 3)
        })

    except Exception as e:
        logging.error(f"Prediction error: {str(e)}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
