
"""
Smart Waste Classification - Streamlit Frontend
Author: The Fab Five
Description: Web interface for users to upload waste images and receive real-time classification results.
"""

import streamlit as st
import requests
from PIL import Image

# Page configuration
st.set_page_config(page_title="Smart Waste Classifier", layout="centered")

# Title and instructions
st.title("♻️ Smart Waste Classification System")
st.markdown("Upload a waste material image and get a real-time classification based on our AI model.")

# File uploader
uploaded_file = st.file_uploader("Choose an image file (JPG, JPEG, PNG):", type=["jpg", "jpeg", "png"])

# Display and prediction
if uploaded_file is not None:
    image_data = Image.open(uploaded_file)
    st.image(image_data, caption="Preview of Uploaded Image", use_column_width=True)

    with st.spinner("Analyzing the image..."):
        try:
            files = {"file": uploaded_file.getvalue()}
            response = requests.post("http://localhost:5000/predict", files=files)

            if response.status_code == 200:
                result = response.json()
                st.success(f"🧾 Prediction: **{result['label']}**")
                st.info(f"📊 Confidence: **{result['confidence'] * 100:.2f}%**")
            else:
                st.error(f"❌ Server Error: {response.json().get('error', 'Unknown issue')}")

        except Exception as e:
            st.error(f"⚠️ Request failed: {e}")
